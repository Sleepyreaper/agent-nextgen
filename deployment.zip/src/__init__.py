"""Azure AI Foundry Multi-Agent System."""

__version__ = "0.1.0"
